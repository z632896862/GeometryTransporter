import numpy as  np
A = np.array([[2,4],[5,-6]])
B = np.array([[9,-3],[3,6]])
C=A+B
print(C)

A1=np.array([[3,6,7],[5,-3,0]])
B1=np.array([[1,1],[2,1],[3,-3]])
C1=A1.dot(B1)
print(C1)

A2=np.array([[1,1],[2,1],[3,-3]])
print(A2.transpose())


