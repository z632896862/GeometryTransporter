import numpy as np;

a=np.array([1,2,3])
print(a)
print(type(a))

A=np.array([[1,2,3],[3,4,5]])
print(A)

B=np.array([[1.1,2,3],[3,4,5]])
print(B)

C=np.array([[1,2,3],[3,4,5]],dtype=complex)
print(C)

zero_array =np.zeros((2,3))
print(zero_array)

ones_array=np.ones((1,5),dtype=np.int32)
print(ones_array)