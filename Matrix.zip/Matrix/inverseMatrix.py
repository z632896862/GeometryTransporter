import numpy as np

E=np.mat([[0.5,0],[0,0.5]])
print(E.I)
print(E.A)

print(E*E.T)