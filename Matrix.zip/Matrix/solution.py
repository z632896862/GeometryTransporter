import numpy as np
from flask import Flask,request,jsonify
from flask import render_template
a=np.mat("1,118.43703,28.94712133;1,118.5473583,28.94858925;1,118.6739431,28.93265986")
b=np.mat("  3.887; 4.302; 4.845")

print(a.I*b.A)
app=Flask(__name__)


def handleData(a):
    coffiency=[]
    vec=[]
    b=a.strip().split(";")
    b=b[:-1]
    for i in b:
        temp=[1]
        c=i.strip().split(",")
        temp+=[float(i) for i in c[:2]]
        vec.append([float(i) for i in c[-1:]])
        coffiency.append(temp)
    coffiency=np.mat(coffiency)
    print(coffiency)
    vec=np.mat(vec)
    print(vec)

    result =coffiency.I*vec
    print("text",result.A[0][0])
    print("longitude",result.A[1][0])
    print("latitude",result.A[2][0])
    print("{p1}+{p2}*longitude+{p3}*latitude".format(p1=result.A[0][0],p2=result.A[1][0],p3=result.A[2][0]))
    return "({p1})+({p2})*longitude+({p3})*latitude".format(p1=result.A[0][0],p2=result.A[1][0],p3=result.A[2][0])

@app.route("/")
def hello():
    # templates =Template('Hello{{name}}!')
    return  render_template("index.html")

@app.route("/cal",methods=["POST"])
def calculate():
    text = request.form["txt"]
    print(text)
    vTformat=handleData(text)
    print(vTformat)
    return jsonify({
        "data":vTformat
    })



if __name__=="__main__":
    app.run(port=5001,threaded=True,host=('0.0.0.0'))

